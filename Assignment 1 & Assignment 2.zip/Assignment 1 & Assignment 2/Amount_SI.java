package Assignment1;
public class Amount_SI {
	public static void main(String[] args) {
		double principal = 50000;
		double time = 6;
		double rate = 4;
		double SI = (principal * time * rate) / 100;
		double amount = principal + SI;
		System.out.println("Given Principal: " + principal);
		System.out.println("Given Time: " + time + " years");
		System.out.println("Given Rate: " + rate + "%");
		System.out.println("Simple Interest (SI): " + SI);
		System.out.println("Total Amount: " + amount);
		}
}
	