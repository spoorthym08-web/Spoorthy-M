package Assignment1;
import java.util.Scanner;
public class largestbetween_number {
public static void main(String[] args) {
	int a=10,b=12,c=30,d=50,e=80;
	if (a>b && a>c && a>d && a>e)
	{
		System.out.println("a is max");
	}
	else if (b>a && b>c && b>d && b>e)
	{
		System.out.println("b is max");
	}
	else if (c>a && c>b && c>d && c>e)
	{
		System.out.println("c is max");
	}
	else if (d>a && d>b && d>c && b>e)
	{
		System.out.println("d is max");
	}
	else 
	{
		System.out.println("e is max");
	}
}
}
