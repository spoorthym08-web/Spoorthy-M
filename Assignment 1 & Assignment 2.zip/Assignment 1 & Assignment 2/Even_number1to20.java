package Assignment1;
import java.util.Scanner;
public class Even_number1to20 {
public static void main(String[] args)
{
	int sum=0;
	for(int i=1;i<=20;i++)
	{
		if(i%2==0)
		{
			sum=sum+i;
		}
	}
 System.out.println("Final sum value is: " +sum);
	}
}
