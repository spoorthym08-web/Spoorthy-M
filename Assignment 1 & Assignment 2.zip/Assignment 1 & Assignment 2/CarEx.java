package Assignment1;


class Car 
{
	private String Band;

	public String getBand() {
		return Band;
	}

	

}
public class CarEx {

	public static void main(String[] args) {
		
		Car obj=new Car();
		System.out.println(obj.getBand());
	}

}
