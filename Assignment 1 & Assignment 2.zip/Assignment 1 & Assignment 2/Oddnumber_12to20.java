package Assignment1;
import java.util.Scanner;
public class Oddnumber_12to20 {

	public static void main(String[] args) {
		int sum=0;
		for(int i=12;i<=20;i++)
		{
			if(i%2!=0)
			{
				sum=sum+i;
				System.out.println("Adding odd number: " + i);
			}
		}
	 System.out.println("Final sum value is: " +sum);
			}
}
