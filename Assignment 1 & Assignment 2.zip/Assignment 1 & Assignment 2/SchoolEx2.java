package Assignment1;

public class SchoolEx2 
{
	    public String name;
	    public String address;
	    public int strength;
	 
	    public SchoolEx2(String Name,String Address) 
	    {
	        this.name = Name;
	        this.address = Address;
	    }
	    public SchoolEx2(String Name,String Address,int Strength)
	    {
	        this.name = Name;
	        this.address = Address;
	        this.strength = Strength;
	    }
	    public void Details1() 
	    {
	    	System.out.println("School Name:    " + name);
	        System.out.println("Address:        " + address);
	        System.out.println("Student Count:  " + strength);
	    }

	public static void main(String[] args)
	{
		 SchoolEx2 obj1 = new SchoolEx2("Delhi Public School", "Sector 4, R.K. Puram");
		 obj1.Details1();
		 SchoolEx2 obj2 = new SchoolEx2("St.Mary's High School", "MG Road, Kolkata", 1500);
		 obj2.Details1();
	}

}
    
  

   

