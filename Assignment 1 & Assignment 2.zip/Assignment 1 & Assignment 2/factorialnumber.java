package Assignment1;
import java.util.Scanner;
public class factorialnumber {
     public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		//System.out.println("Enter any number :");
		int factorial=1;
		int number=5;
		for(int i=1;i<=number;i++)
		{
			factorial=factorial*i;
		}
		System.out.println("Factorial number is:" +factorial);
	}
}
