package Assignment1;
import java.util.Scanner;
public class Armstrongnumber {
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter the number:");
	int number=sc.nextInt();
	int r=number,rev=0;
	while(number!=0)
	{
		int digit=number%10;
		rev=rev+(digit*digit*digit);
		number=number/10;
	}
	System.out.println("Reverse of number is :" +rev);
	if(r==rev)
	{
		System.out.println("Your number is Armstrong number");
	}else
	{
		System.out.println("Number is Armstrong number");	
	}
}
}

