package Assignment1;
import java.util.Scanner;
public class Shape 
{
    double length = 10.0, width = 5.0; 
    public void square() 
    {
        double area = length * length;
        System.out.println("Area of Square : " + area);
    }
    public void rectangle() 
    {
        double area = length * width;
        System.out.println("Area of Rectangle : " + area);
    }
    public void circle() 
    {
        double area = Math.PI * length * length;
        System.out.printf("Area of Circle : %.2f", area);
    }

    public static void main(String[] args)
    { 
     Shape Obj = new Shape();
        Obj.square();
        Obj.rectangle();
        Obj.circle();
    }
}



	
