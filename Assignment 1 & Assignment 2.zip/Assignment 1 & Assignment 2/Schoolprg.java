package Assignment1;
public class Schoolprg
{
  String name;

  public Schoolprg()
 {
	 this.name= "National Public School";
	
 }
  public void display()
  {
  System.out.println("School Name is: " +this.name);
  }
  public void displaylocation() 
  {
	  System.out.println("This School is based out of Kolkata");
  }
  
	public static void main(String[] args)
	{
		Schoolprg obj=new Schoolprg();
		obj.display();
		obj.displaylocation();
}
}
